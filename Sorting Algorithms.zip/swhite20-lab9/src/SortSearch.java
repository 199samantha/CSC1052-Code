/**
 * Search and Sort Methods.
 * 
 * @author Your Name Here
 *
 */
public class SortSearch
{
	/**
	 * Performs a binary search by reducing the search range within the array
	 * after each comparison.
	 *
	 * @param list the array to be searched
	 * @param target the value being searched for
	 * @return the index of the target value if found, or -1 if not
	 */
	public static int binarySearch(String[] list, String target)
	{
		// implement me
		int beg = 0;
		int end = list.length -1;
		int mid;
		
		while (end >= beg)
		{
			mid = (beg+end)/2;
			if (target.equals(list[mid]))
			{
				return mid;
			}
			else if (target.compareTo(list[mid]) < 0)
			{
				end = mid -1;
			}
			else
			{
				beg = mid +1;
			}
		}
		return -1;
	}
	
	/**
	 * Performs a selection sort on the specified string array.
	 *
	 * @param list the array to be sorted
	 */
	public static void selectionSort(String[] list)
	{
		  int min;
		  String temp;
		    for (int i = 0; i < list.length - 1; i++)
		    {
		        min = i;
		        for (int j = i + 1; j < list.length; j++)
		        {
		            if (list[j].compareTo(list[min]) < 0)
		            {
		            	min = j;
		            }
		        }
		        temp = list[i];
		        list[i] = list[min];
		        list[min] = temp;
		    }   
	}
	
	/**
	 * Performs an insertion sort on the specified string array.
	 *
	 * @param list the array to be sorted
	 */
	public static void insertionSort(String[] list)
	{
		
		   for (int i = 1; i < list.length; i++)
		    {
		        String name = list[i];

		        int j = i;
		        while (j > 0 && (list[j - 1].compareTo(name) > 0))
		        {
		            list[j] = list[j - 1];
		            j--;
		        }

		        list[j] = name;
		        
	}
	}
	
	/**
	 * Performs a bubble sort on the specified string array.
	 *
	 * @param list the array to be sorted
	 */
	public static void bubbleSort(String[] list)
	{
		String name;
		for (int j = 0; j < list.length; j++)
		{
	   	   for (int i = j + 1; i < list.length; i++)
	   	   {
			if (list[i].compareTo(list[j]) < 0) 
			{
				name = list[j];
				list[j] = list[i];
				list[i] = name;
			}
	   	   }
		}
	   	 
	}
	
	/**
	 * Performs a quick sort on the specified string array.
	 *
	 * @param list the array to be sorted
	 */
	public static void quickSort(String[] list)
	{
		 quickSort(list, 0, list.length - 1);
	} 

	/**
	 * Recursively performs a quick sort on the segment of the
	 * specified string array from the the low to high elements.
	 * @param list the array to be sorted
	 * @param low the lowest index of the segment
	 * @param high the highest index of the segment
	 */
	public static void quickSort(String[] list, int low, int high)
	{
	    if (low >= 0 && high >= 0 && low < high)
	    {
	       
	        int pivot = partition(list, low, high);

	        
	        quickSort(list, low, pivot - 1); 
	        quickSort(list, pivot + 1, high); 
	    }
	}

	/**
	 * Partitions the segment of the specified string array
	 * from the low to high elements, returning the index of
	 * the pivot element. After partitioning, the array looks like this:
	 *	 L L L L L L L L P G G G G
	 * Values that are less than (L) or greater than (G) the pivot
	 * value (P) are moved before or after the pivot in the array.
	 * The index of the pivot is returned.
	 * @param list the array to be sorted
	 * @param low the lowest index of the segment
	 * @param high the highest index of the segment
	 * @return the index of the pivot element
	 */
	private static int partition(String[] list, int low, int high)
	{
		  String pivot = list[high];

		    int i = low - 1;

		    for (int j = low; j <= high; j++)
		    {
		        if (list[j].compareTo(pivot) <= 0)
		        {
		            i = i + 1;

		           
		            String temp = list[i];
		            list[i] = list[j];
		            list[j] = temp;
		        }
		    }
		    return i;
	}
}

